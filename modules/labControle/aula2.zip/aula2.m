%% Laborat�rio de Controle 2018/2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% T�tulo: Aula 1 - Introdu��o ao Matlab
% Autor: Guilherme Fr�es Silva
% Apostila: Lu�s Fernando Alves Pereira e Jos� Felipe Haffner
% Data: 22/02/2018
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% 1 - Crie um arquivo bas.m 
% que resolva uma equa��o de segunda ordem usando a formula de Bhaskara
%  da forma a*x^2 + b*x + c = 0

% chamando o arquivo bas.m
a = 2;
b = 10;
c = 15;
bas

%% Trabalhando com polin�mios

% x(s) = s^4 + 3*s^3 - 15*s^2 - 2*s + 9
x = [1 3 -15 -2 9]  % Representa um vetor com os coeficientes em ordem decrescente

% y(s) = s^2 + 1
y = [1 0 1]

% Para substituir a variavel e encontrar o valor do polinomio, utilizamos:
polyval(x,2)

% Para encontrar as ra�zes utilizamos a fun��o roots
roots(x)
roots(y)

% Para multiplicar e dividir polinomios utilizamos conv e deconv
z = conv(x,y)

[yy, R] = deconv(z,x)

% Resolvendo sistemas de equa��es lineares
% a*x1 + b*x2 = p
% c*x1 + d*x2 = q
% Reescrevemos de forma matricial:
% A*X = B, onde:
% A = [a b; c d]; B = [p q]'; X = [x1 x2]';
% Se a matriz A possuir inversa (det(A)!=0), a solu��o �:
# X = A^(-1)*B

% Exemplo: 
% 2*x1 + 5*x2 = 10
% 3*x1 - 2*x2 = 3
A = [2 5; 3 -2];
B = [10 3]';
% X = A/B % Divis�o normal de matrizes, dimens�es n�o s�o compativeis 
X = A\B % lembrando que X = [x1 x2];

%% Elementos de Programa��o
% Comando IF usa operadores l�gicos de compara��o:
% MAIOR >  ; MAIOR IGUAL >=
% MENOR <  ; MENOR IGUAL <=
% IGUAL == ; DIFERENTE ~= ou !=

% exemplo 1
n = 10*rand; % a fun��o rand gera numeros aleatorios entre 0 e 1.
             % randn gera numeros aleat�rios seguindo a distribui��o normal
if n <= 5
  fprintf('o numero � menor ou igual a 5\n')
else
  fprintf('o numero � maior que 5\n')
end
  
% exemplo 2
  if n == 5
  fprintf('o numero � igual a 5\n')
elseif n < 5
  fprintf('o numero � menor que 5\n')
else
  fprintf('o numero � maior que 5\n')
end

% Comando FOR - Repete o loop um numero determinado de vezes ou at� atingir
% a clausula BREAK
H = [1 2 3 4 5; 6 7 8 9 10; 11 12 13 14 15];
m = 5;
n = 3;
for ii = 1:m
  for jj = 1:n
    HT(ii,jj) = H(jj,ii);
  end
end
disp(H)
disp(H')
disp(HT)
if H' == HT
  fprintf('As matrizes s�o iguais.\n');
end

% Comando BREAK - interrompe a execu��o de um loop
% Comando RETURN - interrompe a execu��o do programa
% Comando DISP - utilizado para mostrar vari�veis ou caracteres
%     Sempre acaba com um '\n' - nova linha

% Comando ERROR - joga um erro , interrompendo a execu��o do programa
% Comando input pode ser utilizado para entrada de dados pelo usu�rio
var = input('digite o valor de "var": ')

% usando parametro 's' para receber texto literal string
varc = input('digite um texto para "varc": ', 's')

%% Salvando e carregando arquivos de dados
% Comando SAVE - salva dados com extens�o .mat
save variavel var varc

clear var, clear varc
% Comando LOAD - carrega as variaveis salvas num arquivo .mat
load variavel.mat

%% Criando Fun��es
% Crie uma fun��o que resolva uma equa��o de segunda ordem usando a f�rmula de
%   bhaskara, aceitando os coeficientes como entrada e retornando os valores de
%   'x' como solu��o.
a = 2;
b = 10;
c = 15;
bas2(a,b,c)

% exemplo da apostila
x1 = 10;
y1 = 10;
[m, a] = polar1(x1, y1)
% usando a fun��o bulit-in do MATLAB:
[a, m] = cart2pol(x1, y1) % angulo em radianos
a_d = a*180/pi            % convers�o para graus