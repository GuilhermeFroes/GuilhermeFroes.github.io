% Resolve uma equa��o de Bhaskara da forma a*x^2 + b*x + c = 0
d = sqrt(b^2 - 4*a*c)/(2*a);
e = b/(2*a);
r1 = e + d; % ra�z 1
r2 = e - d; % ra�z 2
sol = [r1; r2];