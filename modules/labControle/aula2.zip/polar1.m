function [modulo, angulo] = polar1(x,y)
  % converte cordenadas retangulares em coordenadas polares
  % o angulo � convertido em graus
  
  if nargin ~= 2 % testa o numero de par�metros de entrada
    error('n�mero de parametros diferente de 2') 
    return
  end
  
  modulo = sqrt(x^2+y^2);
  k=180/pi; % constante para converter rad em graus
  angulo = k*atan2(y,x)
end