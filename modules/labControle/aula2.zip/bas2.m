function sol = bas2(a,b,c)
  % Resolve uma equa��o de segunda ordem da forma a*x^2 + b*x + c = 0
  if nargin ~= 3
    return
  end
  
  d = sqrt(b^2 - 4*a*c)/(2*a);
  e = b/(2*a);
  r1 = e + d; % ra�z 1
  r2 = e - d; % ra�z 2
  sol = [r1; r2];
end