% Resolvendo a EDO: xdot = sin(t). Ou seja, calcular a integral do sen(t).

t = 0:0.1:2*pi; % vetor tempo, amostrado a cada 100ms, at� 2*pi
%clf(1),clf(2)   % limpa as figuras 1 e 2
figure(1)       % abre (ou seleciona)  a figura 1

subplot(2,1,1)
vet0(t>0) = 0; % vetor de zeros do tamanho de t
plot(t,vet0,'--'); 
hold on % plots agora n�o sobreescrevem os anteriores
plot(t,sin(t))
axis([0 2*pi -2 2]) % definindo os eixos
title('sin(t)')     % definindo o titulo

subplot(2,1,2)
plot(t,vet0,'--'); hold on
plot(t,cos(t))
axis([0 2*pi -2 2])
title('cos(t)')

%%
figure(2)

subplot(2,1,1)
plot(t,vet0,'--'); hold on
plot(t,sin(t))
axis([0 2*pi -2 2])
title('sin(t)')


subplot(2,1,2)
plot(t,vet0,'--'); hold on
plot(t,1-cos(t),'r')
plot(t,cos(t),'b')
axis([0 2*pi -2 2])
title('int(sin(t))')